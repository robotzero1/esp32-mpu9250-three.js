import { Geometry } from '../../../src/Three';

export function UVsDebug( geometry: Geometry, size: number ): HTMLCanvasElement;
